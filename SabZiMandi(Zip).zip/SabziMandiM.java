import java.util.Scanner;







public class SabziMandiM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		System.out.println();
		System.out.println("                  ******--{ WELCOME TO SabZiMandi }--******                  ");
		System.out.println();
		
		System.out.print("Enter your username        : ");
		//int usernameString=scanner.nextInt();
		String usernameString=scanner.nextLine();
		
	
		if(usernameString=="akankush2000"||usernameString=="akankushjnvku"||usernameString=="abhishek"||usernameString=="aryan"||usernameString=="animesh"||
				usernameString=="prabhat"||usernameString=="ankit") {
			System.out.println("Hello "+usernameString);
			System.out.println(usernameString+" please enter your password: ");
			int password=scanner.nextInt();
			if(password==1234||password==4321) {
				System.out.println("***SUCCESSFULLY LOGIN'D");
				
			}
			else {
				System.out.println("wrong user!");
				
			}
			
		}
		System.out.print("Enter your delivery address: ");
		String addressString=scanner.nextLine();
		
		
		System.out.println();
		
		System.out.println("              --------< HELLO "+usernameString+" WELCOME TO RAJEEV NAGAR  >--------");
		System.out.println();
		System.out.println("   1.VEGETARIAN ITEMS");
		System.out.println("   2.NON-VEGETARIAN ITEMS");
		System.out.println();
		System.out.print("Please input your choices: ");
		
		
	    int inputVal=scanner.nextInt();
	    switch(inputVal) {
	    case 1:{
	        System.out.println();
	    	System.out.println("                  ***VEGETARIAN CORNER***      ");
	        System.out.println();
	    	System.out.print("  1.RAJU ");
	        System.out.print("  2.KARAN ");
	        System.out.print("  3.TARUN ");
	        System.out.print("  4.SHYAM ");
	        System.out.print("  5.PANKAJ ");
	        System.out.println();
	        System.out.println();
	        System.out.print("Please choose your shopkeeper: ");
	        
	        int inputVal1=scanner.nextInt();
	        
	        switch(inputVal1) {
	        case 1:{
	        	int Bhindi=20,Potato=30,Tomato=21,Ginger=10;
	        	double Bhindi1=10,Potato1=15,Tomato1=10.5,Ginger1=5;
	        	System.out.println();
	        	System.out.println("         --< RAJU'S SHOP >--");
	        	System.out.println();
	            System.out.print("    ( 1Kg Prices )");
	            System.out.println("    ( 1/2Kg Prices )");
	            System.out.println();
	        	System.out.print("    1.Bhindi="+Bhindi+"/-");
	        	System.out.println("      5.Bhindi="+Bhindi1+"/-");
	        	System.out.print("    2.Potato="+Potato+"/-");
	        	System.out.println("      6.Potato="+Potato1+"/-");
	        	System.out.print("    3.Tomato="+Tomato+"/-");
	        	System.out.println("      7.Tomato="+Tomato1+"/-");
	        	System.out.print("    4.Ginger="+Ginger+"/-");
	        	System.out.println("      8.Ginger="+Ginger1+"/-");
	        	System.out.println();
	        	System.out.print("Add your items: ");
	        	int addItem=scanner.nextInt();
	        	if(addItem==1) {
	        		int Total=Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
	                
	        		return;
	        	}
	        	else if(addItem==12 || addItem==21){
	        		int Total=Bhindi+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==24 || addItem==42){
	        		int Total=Ginger+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==23 || addItem==32){
	        		int Total=Tomato+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==13 || addItem==31){
	        		int Total=Bhindi+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==14 || addItem==41){
	        		int Total=Bhindi+Ginger;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==34 || addItem==43){
	        		int Total=Ginger+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==123 || addItem==321 || addItem==213 || addItem==132 || addItem==231|| addItem==312) {
	        		int Total=Bhindi+Potato+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        		else if(addItem==124 || addItem==421 || addItem==214 || addItem==142 || addItem==241|| addItem==412
		        			||addItem==234 || addItem==243 || addItem==342 || addItem==324 || addItem==432|| addItem==423) {
		        		int Total=Bhindi+Potato+Ginger;
		        		System.out.println();
		        		System.out.println("   *******************");
		                System.out.println("      Grand Total: "+Total+"/-");
		                System.out.println("   *******************");
		                System.out.println();
		                System.out.println();
		                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

		        		return;
	        		
	        		
	        	}
	        	else if(addItem==1234||addItem==1243||addItem==1324||addItem==1423||addItem==2341||addItem==2431||addItem==2134||addItem==2341||addItem==2143||addItem==2413||addItem==2314||
	        			addItem==3124||addItem==3142||addItem==3412||addItem==3421||addItem==3241||addItem==3214||addItem==4123||addItem==4132||addItem==4312||addItem==4321||addItem==4231||addItem==4213) {
	        		int Total=Bhindi+Potato+Tomato+Ginger;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==5)
	        	{
	        		double Total=Bhindi1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==6)
	        	{
	        		double Total=Potato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==7)
	        	{
	        		double Total=Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==8)
	        	{
	        		double Total=Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==56|| addItem==65)
	        	{
	        		double Total=Bhindi1+Potato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==57|| addItem==75)
	        	{
	        		double Total=Bhindi1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==58|| addItem==85)
	        	{
	        		double Total=Bhindi1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==567|| addItem==576||addItem==657||addItem==675||addItem==756||addItem==765)
	        	{
	        		double Total=Bhindi1+Potato1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}else if(addItem==678|| addItem==687||addItem==768||addItem==786||addItem==867||addItem==876)
	        	{
	        		double Total=Ginger1+Potato1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==785|| addItem==758||addItem==875||addItem==857||addItem==578||addItem==587)
	        	{
	        		double Total=Bhindi1+Ginger1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==568|| addItem==586||addItem==658||addItem==685||addItem==856||addItem==865)
	        	{
	        		double Total=Bhindi1+Potato1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==15|| addItem==51)
	        	{
	        		double Total=Bhindi1+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==16|| addItem==61)
	        	{
	        		double Total=Potato1+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==17|| addItem==71)
	        	{
	        		double Total=Tomato1+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==18|| addItem==81)
	        	{
	        		double Total=Ginger1+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	
	        	
	        	
	        	
	        	else if(addItem==25|| addItem==52)
	        	{
	        		double Total=Bhindi1+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==26|| addItem==62)
	        	{
	        		double Total=Potato1+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==27|| addItem==72)
	        	{
	        		double Total=Tomato1+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==28|| addItem==82)
	        	{
	        		double Total=Ginger1+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	
	        	
	        	
	        	else if(addItem==35|| addItem==53)
	        	{
	        		double Total=Bhindi1+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==36|| addItem==63)
	        	{
	        		double Total=Potato1+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==37|| addItem==73)
	        	{
	        		double Total=Tomato1+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==38|| addItem==83)
	        	{
	        		double Total=Ginger1+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	
	        	
	        	
	        	else if(addItem==45|| addItem==54)
	        	{
	        		double Total=Bhindi1+Ginger;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==46|| addItem==64)
	        	{
	        		double Total=Potato1+Ginger;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==47|| addItem==74)
	        	{
	        		double Total=Tomato1+Ginger;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==48|| addItem==84)
	        	{
	        		double Total=Ginger1+Ginger;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	//********************end of 2 combinations(1/2 kg)
	        	
	        	
	        	else if(addItem==125|| addItem==152||addItem==215||addItem==251||addItem==512||
	        			addItem==521)
	        	{
	        		double Total=Bhindi+Potato+Bhindi1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==126|| addItem==162||addItem==216||addItem==261||addItem==612||
	        			addItem==621)
	        	{
	        		double Total=Bhindi+Potato+Potato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==127|| addItem==172||addItem==217||addItem==271||addItem==712||
	        			addItem==721)
	        	{
	        		double Total=Bhindi+Potato+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==128|| addItem==182||addItem==218||addItem==281||addItem==812||
	        			addItem==821)
	        	{
	        		double Total=Bhindi+Potato+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==135|| addItem==153||addItem==315||addItem==351||addItem==513||
	        			addItem==531)
	        	{
	        		double Total=Bhindi+Tomato+Bhindi1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==136|| addItem==163||addItem==316||addItem==361||addItem==613||
	        			addItem==631)
	        	{
	        		double Total=Bhindi+Tomato+Potato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==137|| addItem==173||addItem==317||addItem==371||addItem==713||
	        			addItem==731)
	        	{
	        		double Total=Bhindi+Tomato+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==138|| addItem==183||addItem==318||addItem==381||addItem==813||
	        			addItem==831)
	        	{
	        		double Total=Bhindi+Tomato+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==145|| addItem==154||addItem==415||addItem==451||addItem==514||
	        			addItem==541)
	        	{
	        		double Total=Bhindi+Ginger+Bhindi1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==146|| addItem==164||addItem==416||addItem==461||addItem==614||
	        			addItem==641)
	        	{
	        		double Total=Bhindi+Ginger+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==147|| addItem==174||addItem==417||addItem==714||addItem==471||
	        			addItem==741)
	        	{
	        		double Total=Bhindi+Ginger+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==148|| addItem==184||addItem==418||addItem==481||addItem==814||
	        			addItem==841)
	        	{
	        		double Total=Bhindi+Ginger+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	
	        	//1st three mix
	        	
	        	
	        	else if(addItem==156|| addItem==165||addItem==516||addItem==561||addItem==615||
	        			addItem==651)
	        	{
	        		double Total=Bhindi+Bhindi1+Potato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==157|| addItem==175||addItem==517||addItem==571||addItem==715||
	        			addItem==751)
	        	{
	        		double Total=Bhindi+Bhindi1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==158|| addItem==185||addItem==518||addItem==581||addItem==815||
	        			addItem==851)
	        	{
	        		double Total=Bhindi+Bhindi1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==257|| addItem==275||addItem==527||addItem==572||addItem==725||
	        			addItem==752)
	        	{
	        		double Total=Potato+Bhindi1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==256|| addItem==265||addItem==526||addItem==562||addItem==625||
	        			addItem==652)
	        	{
	        		double Total=Potato+Bhindi1+Potato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}else if(addItem==258|| addItem==285||addItem==528||addItem==582||addItem==825||
	        			addItem==852)
	        	{
	        		double Total=Potato+Bhindi1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==356|| addItem==365||addItem==536||addItem==563||addItem==635||
	        			addItem==653)
	        	{
	        		double Total=Tomato+Bhindi1+Potato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==357|| addItem==375||addItem==537||addItem==573||addItem==735||
	        			addItem==753)
	        	{
	        		double Total=Tomato+Bhindi1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==358|| addItem==385||addItem==538||addItem==583||addItem==835||
	        			addItem==853)
	        	{
	        		double Total=Bhindi1+Tomato+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}else if(addItem==456|| addItem==465||addItem==546||addItem==564||addItem==645||
	        			addItem==654)
	        	{
	        		double Total=Ginger+Bhindi1+Potato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==457|| addItem==475||addItem==547||addItem==574||addItem==745||
	        			addItem==754)
	        	{
	        		double Total=Ginger+Bhindi1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();	                
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==458|| addItem==485||addItem==548||addItem==584||addItem==845||
	        			addItem==854)
	        	{
	        		double Total=Ginger+Bhindi1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	
	        	
	        	//resting
	        	
	        	
	        	else if(addItem==167|| addItem==176||addItem==617||addItem==671||addItem==716||
	        			addItem==761)
	        	{
	        		double Total=Bhindi+Potato1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==168|| addItem==186||addItem==618||addItem==681||addItem==816||
	        			addItem==861)
	        	{
	        		double Total=Bhindi+Potato1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==185|| addItem==158||addItem==815||addItem==851||addItem==518||
	        			addItem==581)
	        	{
	        		double Total=Bhindi+Bhindi1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==267|| addItem==276||addItem==627||addItem==672||addItem==726||
	        			addItem==762)
	        	{
	        		double Total=Potato+Potato1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==268|| addItem==286||addItem==628||addItem==682||addItem==826||
	        			addItem==862)
	        	{
	        		double Total=Potato+Potato1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==285|| addItem==258||addItem==825||addItem==852||addItem==528||
	        			addItem==582)
	        	{
	        		double Total=Potato+Bhindi1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==367|| addItem==376||addItem==637||addItem==673||addItem==736||
	        			addItem==763)
	        	{
	        		double Total=Tomato+Potato1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==368|| addItem==386||addItem==638||addItem==683||addItem==836||
	        			addItem==863)
	        	{
	        		double Total=Tomato+Potato1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==358|| addItem==385||addItem==835||addItem==853||addItem==538||
	        			addItem==583)
	        	{
	        		double Total=Tomato+Bhindi1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==467|| addItem==476||addItem==647||addItem==674||addItem==746||
	        			addItem==764)
	        	{
	        		double Total=Ginger+Potato1+Tomato1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==468|| addItem==486||addItem==648||addItem==684||addItem==846||
	        			addItem==864)
	        	{
	        		double Total=Ginger+Potato1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==458|| addItem==485||addItem==548||addItem==584||addItem==845||
	        			addItem==854)
	        	{
	        		double Total=Ginger+Bhindi1+Ginger1;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==843|| addItem==834||addItem==483||addItem==438||addItem==384||
	        			addItem==348)
	        	{
	        		double Total=Ginger1+Ginger+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==842|| addItem==824||addItem==482||addItem==428||addItem==284||
	        			addItem==248)
	        	{
	        		double Total=Ginger1+Ginger+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==841|| addItem==814||addItem==481||addItem==418||addItem==184||
	        			addItem==148)
	        	{
	        		double Total=Ginger1+Ginger+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==832|| addItem==823||addItem==382||addItem==328||addItem==283||
	        			addItem==238)
	        	{
	        		double Total=Ginger1+Tomato+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==831|| addItem==813||addItem==381||addItem==318||addItem==183||
	        			addItem==138)
	        	{
	        		double Total=Ginger1+Tomato+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==821|| addItem==812||addItem==281||addItem==218||addItem==182||
	        			addItem==128)
	        	{
	        		double Total=Ginger1+Potato+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==743|| addItem==734||addItem==473||addItem==437||addItem==374||
	        			addItem==347)
	        	{
	        		double Total=Tomato1+Ginger+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==742|| addItem==724||addItem==472||addItem==427||addItem==274||
	        			addItem==247)
	        	{
	        		double Total=Tomato1+Ginger+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==741|| addItem==714||addItem==471||addItem==417||addItem==174||
	        			addItem==147)
	        	{
	        		double Total=Tomato1+Ginger+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==732|| addItem==723||addItem==372||addItem==327||addItem==273||
	        			addItem==237)
	        	{
	        		double Total=Tomato1+Tomato+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==731|| addItem==713||addItem==371||addItem==317||addItem==173||
	        			addItem==137)
	        	{
	        		double Total=Tomato1+Tomato+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==721|| addItem==712||addItem==271||addItem==217||addItem==172||
	        			addItem==127)
	        	{
	        		double Total=Tomato1+Potato+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==643|| addItem==634||addItem==463||addItem==436||addItem==364||
	        			addItem==346)
	        	{
	        		double Total=Potato1+Ginger+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==642|| addItem==624||addItem==462||addItem==426||addItem==264||
	        			addItem==246)
	        	{
	        		double Total=Potato1+Ginger+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==641|| addItem==614||addItem==461||addItem==416||addItem==164||
	        			addItem==146)
	        	{
	        		double Total=Potato1+Ginger+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==632|| addItem==623||addItem==362||addItem==326||addItem==263||
	        			addItem==236)
	        	{
	        		double Total=Potato1+Tomato+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==631|| addItem==613||addItem==361||addItem==316||addItem==163||
	        			addItem==136)
	        	{
	        		double Total=Potato1+Tomato+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==621|| addItem==612||addItem==261||addItem==216||addItem==162||
	        			addItem==126)
	        	{
	        		double Total=Potato1+Potato+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==543|| addItem==534||addItem==453||addItem==435||addItem==354||
	        			addItem==345)
	        	{
	        		double Total=Ginger+Bhindi1+Tomato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==542|| addItem==524||addItem==452||addItem==425||addItem==254||
	        			addItem==245)
	        	{
	        		double Total=Ginger+Bhindi1+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==541|| addItem==514||addItem==451||addItem==415||addItem==154||
	        			addItem==145)
	        	{
	        		double Total=Ginger+Bhindi1+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==532|| addItem==523||addItem==352||addItem==325||addItem==253||
	        			addItem==235)
	        	{
	        		double Total=Tomato+Bhindi1+Potato;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==531|| addItem==513||addItem==351||addItem==315||addItem==153||
	        			addItem==135)
	        	{
	        		double Total=Tomato+Bhindi1+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	else if(addItem==521|| addItem==512||addItem==251||addItem==215||addItem==152||
	        			addItem==125)
	        	{
	        		double Total=Potato+Bhindi1+Bhindi;
	        		System.out.println();
	        		System.out.println("   *******************");
	                System.out.println("      Grand Total: "+Total+"/-");
	                System.out.println("   *******************");
	                System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);
                    return;
	        	}
	        	
	  
	        	//resting 2
	        	
	        	
	        	
	  
	        	break;
	        }
	        case 2:{
	        	int Bhindi=21,Potato=33,Tomato=21,Ginger=10;
	        	System.out.println("--< KARAN'S SHOP >--");
	        	System.out.print("    1.Bhindi="+Bhindi+"/-");
	        	System.out.println("    2.Potato="+Potato+"/-");
	        	System.out.print("    3.Tomato="+Tomato+"/-");
	        	System.out.println("    4.Ginger="+Ginger+"/-");
	        	System.out.print("Add your items: ");
	        	int addItem=scanner.nextInt();
	        	if(addItem==1) {
	        		int Total=Bhindi;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==12 || addItem==21){
	        		int Total=Bhindi+Potato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==24 || addItem==42){
	        		int Total=Ginger+Potato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==23 || addItem==32){
	        		int Total=Tomato+Potato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==13 || addItem==31){
	        		int Total=Bhindi+Tomato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==14 || addItem==41){
	        		int Total=Bhindi+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==34 || addItem==43){
	        		int Total=Ginger+Tomato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        		
	        		
	        		
	        		
	        	}
	        	else if(addItem==123 || addItem==321 || addItem==213 || addItem==132 || addItem==231|| addItem==312) {
	        		int Total=Bhindi+Potato+Tomato;
	        		System.out.println("Total Price: "+Total+"/-");
	        		System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        		
	        	}
	        	
	        	else if(addItem==124 || addItem==421 || addItem==214 || addItem==142 || addItem==241|| addItem==412
	        			||addItem==234 || addItem==243 || addItem==342 || addItem==324 || addItem==432|| addItem==423) {
	        		int Total=Bhindi+Potato+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	        		System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==1234||addItem==1243||addItem==1324||addItem==1423||addItem==2341||addItem==2431||addItem==2134||addItem==2341||addItem==2143||addItem==2413||addItem==2314||
	        			addItem==3124||addItem==3142||addItem==3412||addItem==3421||addItem==3241||addItem==3214||addItem==4123||addItem==4132||addItem==4312||addItem==4321||addItem==4231||addItem==4213) {
	        		int Total=Bhindi+Potato+Tomato+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	break;
	        }
	        case 3:{
	        	int Bhindi=23,Potato=31,Tomato=26,Ginger=15;
	        	System.out.println("--< TARUN'S SHOP >--");
	        	System.out.print("    1.Bhindi="+Bhindi+"/-");
	        	System.out.println("    2.Potato="+Potato+"/-");
	        	System.out.print("    3.Tomato="+Tomato+"/-");
	        	System.out.println("    4.Ginger="+Ginger+"/-");
	        	System.out.print("Add your items: ");
	        	int addItem=scanner.nextInt();
	        	if(addItem==1) {
	        		int Total=Bhindi;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==12 || addItem==21){
	        		int Total=Bhindi+Potato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==23 || addItem==32){
	        		int Total=Tomato+Potato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==13 || addItem==31){
	        		int Total=Bhindi+Tomato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==14 || addItem==41){
	        		int Total=Bhindi+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==34 || addItem==43){
	        		int Total=Ginger+Tomato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		
	        	}
	        	else if(addItem==123 || addItem==321 || addItem==213 || addItem==132 || addItem==231|| addItem==312) {
	        		int Total=Bhindi+Potato+Tomato;
	        		System.out.println("Total Price: "+Total+"/-");
	        		System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        		
	        	}
	        	
	        	else if(addItem==124 || addItem==421 || addItem==214 || addItem==142 || addItem==241|| addItem==412
	        			||addItem==234 || addItem==243 || addItem==342 || addItem==324 || addItem==432|| addItem==423) {
	        		int Total=Bhindi+Potato+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	        		System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==1234||addItem==1243||addItem==1324||addItem==1423||addItem==2341||addItem==2431||addItem==2134||addItem==2341||addItem==2143||addItem==2413||addItem==2314||
	        			addItem==3124||addItem==3142||addItem==3412||addItem==3421||addItem==3241||addItem==3214||addItem==4123||addItem==4132||addItem==4312||addItem==4321||addItem==4231||addItem==4213) {
	        		int Total=Bhindi+Potato+Tomato+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	break;
	        }
	        case 4:{
	        	int Bhindi=22,Potato=34,Tomato=21,Ginger=11;
	        	System.out.println("--< SHYAM'S SHOP >--");
	        	System.out.print("    1.Bhindi="+Bhindi+"/-");
	        	System.out.println("    2.Potato="+Potato+"/-");
	        	System.out.print("    3.Tomato="+Tomato+"/-");
	        	System.out.println("    4.Ginger="+Ginger+"/-");
	        	System.out.print("Add your items: ");
	        	int addItem=scanner.nextInt();
	        	if(addItem==1) {
	        		int Total=Bhindi;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==12 || addItem==21){
	        		int Total=Bhindi+Potato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        		
	        	}
	        	else if(addItem==123 || addItem==321 || addItem==213 || addItem==132 || addItem==231|| addItem==312) {
	        		int Total=Bhindi+Potato+Tomato;
	        		System.out.println("Total Price: "+Total+"/-");
	        		System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        		
	        	}
	        	
	        	else if(addItem==124 || addItem==421 || addItem==214 || addItem==142 || addItem==241|| addItem==412
	        			||addItem==234 || addItem==243 || addItem==342 || addItem==324 || addItem==432|| addItem==423) {
	        		int Total=Bhindi+Potato+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	        		System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==1234||addItem==1243||addItem==1324||addItem==1423||addItem==2341||addItem==2431||addItem==2134||addItem==2341||addItem==2143||addItem==2413||addItem==2314||
	        			addItem==3124||addItem==3142||addItem==3412||addItem==3421||addItem==3241||addItem==3214||addItem==4123||addItem==4132||addItem==4312||addItem==4321||addItem==4231||addItem==4213) {
	        		int Total=Bhindi+Potato+Tomato+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	break;
	      
	        }
	        case 5:{
	        	int Bhindi=20,Potato=35,Tomato=22,Ginger=13;
	        	System.out.println("--< PANKAJ'S SHOP>--");
	          	System.out.print("    1.Bhindi="+Bhindi+"/-");
	        	System.out.println("    2.Potato="+Potato+"/-");
	        	System.out.print("    3.Tomato="+Tomato+"/-");
	        	System.out.println("    4.Ginger="+Ginger+"/-");
	        	System.out.print("Add your items: ");
	        	int addItem=scanner.nextInt();
	        	if(addItem==1) {
	        		int Total=Bhindi;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==12 || addItem==21){
	        		int Total=Bhindi+Potato;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        		
	        	}
	        	else if(addItem==123 || addItem==321 || addItem==213 || addItem==132 || addItem==231|| addItem==312) {
	        		int Total=Bhindi+Potato+Tomato;
	        		System.out.println("Total Price: "+Total+"/-");
	        		System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        		
	        	}
	        	
	        	else if(addItem==124 || addItem==421 || addItem==214 || addItem==142 || addItem==241|| addItem==412
	        			||addItem==234 || addItem==243 || addItem==342 || addItem==324 || addItem==432|| addItem==423) {
	        		int Total=Bhindi+Potato+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	        		System.out.println();
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	else if(addItem==1234||addItem==1243||addItem==1324||addItem==1423||addItem==2341||addItem==2431||addItem==2134||addItem==2341||addItem==2143||addItem==2413||addItem==2314||
	        			addItem==3124||addItem==3142||addItem==3412||addItem==3421||addItem==3241||addItem==3214||addItem==4123||addItem==4132||addItem==4312||addItem==4321||addItem==4231||addItem==4213) {
	        		int Total=Bhindi+Potato+Tomato+Ginger;
	                System.out.println("Grand Total: "+Total+"/-");
	                System.out.println("Your "+addItem+" items will be delivered to "+addressString);

	        		return;
	        	}
	        	break;
	        }
	        default:
	        	System.out.println("wrong input!");
	        }
	     break;
	    }
	    case 2:{
	    	System.out.println();
	    	System.out.println("                  ***NON-VEGETARIAN CORNER***      ");
	    	System.out.println();
	    	System.out.println();
	    	
	    	class Nonvege{
	    		int MuttonPriceFull,ChickenPriceFull,FishPriceFull;
	    		int MuttonPriceHalf,ChickenPriceHalf,FishPriceHalf;
	    		int l1,l2,l3,l4,l5,l6;
	    		int l12,l13,l23;
	    		int l123;
	    		int l45,l46,l56;
	    		int l456;
	    		String cutted,uncutted;
	    		String Sellers,items,items2;
	    		
	    		
	    		public void sell(){
	    			Sellers="            1.Imtiyaz  "+"  2.Anwar"+"  3.Anmol"+"  4.Rajat";
	    			
	    			System.out.println("++Please choose your Seller: ");
	    			System.out.println();
	    			System.out.println(this.Sellers);
	    			System.out.println();
	    			}
	    		public void prices() {
	    			MuttonPriceFull=250;
	    			MuttonPriceHalf=125;
	    			ChickenPriceFull=180;
	    			ChickenPriceHalf=90;
	    			FishPriceFull=150;
	    			FishPriceHalf=75;
	    		}
	    		public void prices2() {
	    			MuttonPriceFull=00;
	    			MuttonPriceHalf=00;
	    			ChickenPriceFull=150;
	    			ChickenPriceHalf=75;
	    			FishPriceFull=120;
	    			FishPriceHalf=60;
	    		}
	    		public void prices1() {
	    			 l1=MuttonPriceFull;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l1+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		public void prices22() {
	    			 l2=ChickenPriceFull;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l2+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		public void prices3() {
	    			 l3=FishPriceFull;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l3+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		public void prices4() {
	    			 l4=MuttonPriceHalf;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l4+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		public void prices5() {
	    			 l5=ChickenPriceHalf;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l5+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		public void prices6() {
	    			 l6=FishPriceHalf;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l6+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		
	    		//end of single
	    		
	    		public void prices12() {
	    			 l12=MuttonPriceFull+ChickenPriceFull;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l12+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		
	    		public void prices13() {
	    			 l13=MuttonPriceFull+FishPriceFull;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l13+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    	
	    		public void prices23() {
	    			 l23=FishPriceFull+MuttonPriceFull;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l23+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		
	    		//end of 2 on first phase
	    		
	    		public void prices123() {
	    			 l123=MuttonPriceFull+ChickenPriceFull+FishPriceFull;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l123+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		
	    		
	    		//end of 1st phase 123
	    		
	    		
	    		
	    		//starting of 2nd phase 456
	    		
	    		
	    		
	    		
	    		public void prices45() {
	    			 l45=MuttonPriceHalf+ChickenPriceHalf;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l45+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		
	    		public void prices46() {
	    			 l46=MuttonPriceHalf+FishPriceHalf;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l46+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    	
	    		public void prices56() {
	    			 l56=ChickenPriceHalf+FishPriceHalf;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l56+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		
	    		//end of 2 on first phase
	    		
	    		public void prices456() {
	    			 l456=MuttonPriceHalf+ChickenPriceHalf+FishPriceHalf;
	    			 System.out.println("      ***********");
	    			 System.out.println("      Grand Total = "+this.l456+"/-");
	    			 System.out.println("      ***********");
	    			 }
	    		
	    		
	    		
	    		
	    		public void Items() {
	    			
	    			items="            1.Mutton "+this.MuttonPriceFull+"/-    "+"   4.Mutton "+this.MuttonPriceHalf+"/- \n"
	    			                 +"            2.Chicken "+this.ChickenPriceFull+"/-      "+"5.Chicken "+this.ChickenPriceHalf+"/- \n"+
	    					          "            3.Fish "+this.FishPriceFull+"/-         "+"6.Fish "+this.FishPriceHalf+"/-  ";


	    			
	    			
	    			System.out.println();
	    			System.out.println();
	    			System.out.println("               (1 kg)                (1/2 kg)   ");
	    			System.out.println();
	    			System.out.println(this.items);
	    			System.out.println();
	    		}
	    		
                public void Items2() {
	    			
	    			

	    			items2="            1.Mutton "+this.MuttonPriceFull+"/-    "+"     4.Mutton "+this.MuttonPriceHalf+"/- \n"
			                 +"            2.Chicken "+this.ChickenPriceFull+"/-      "+"5.Chicken "+this.ChickenPriceHalf+"/- \n"+
					          "            3.Fish "+this.FishPriceFull+"/-         "+"6.Fish "+this.FishPriceHalf+"/-  ";
	    			
	    			
	    			System.out.println();
	    			System.out.println();
	    			System.out.println("               (1 kg)                (1/2 kg)   ");
	    			System.out.println();
	    			System.out.println(this.items2);
	    			System.out.println();
	    		}
	    		
	    		
	    		
	    		
	    		
	    		}
	    	
	    	Nonvege nonVegetarian=new Nonvege();
	    	String cuttedString=scanner.nextLine();
	    	
	    	nonVegetarian.cutted=cuttedString;
	    	nonVegetarian.uncutted="yes";
	    	
	    	nonVegetarian.sell();
	    	
	    	
	    	
	    	
	    	
	    	System.out.print("Input your choice: ");
	    	int sellers=scanner.nextInt();
	    	System.out.println();
	    	switch (sellers){
			case 1: {
				if(sellers==1) {
					System.out.println("      ------< Imtiyaz Shop >-----");
					System.out.println();
					System.out.println("Varities: ");
					System.out.println("          1.Cutted");
					System.out.println("          2.Uncutted");
					System.out.println();
					System.out.print("Input the choice: ");
					
					int choice=scanner.nextInt();
					switch (choice) {
					case 1: {
						if(choice==1) {
							nonVegetarian.prices();
							nonVegetarian.Items();
							System.out.println("please choose items: ");
							break;
							
						}
						break;
					}
					case 2:{
						if(choice==2) {
					
						nonVegetarian.prices2();
						nonVegetarian.Items2();
						System.out.print("please choose items: ");
						
						int total2=scanner.nextInt();
						System.out.println();
						if(total2==1) {
							nonVegetarian.prices1();
							System.out.println("");
						}
						else if(total2==2) {
							nonVegetarian.prices22();
							System.out.println("");
						}
						else if(total2==3) {
							nonVegetarian.prices3();
							System.out.println("");
						}
						else if(total2==4) {
							nonVegetarian.prices4();
							System.out.println("");
						}
						else if(total2==5) {
							nonVegetarian.prices5();
							System.out.println("");
						}
						else if(total2==6) {
							nonVegetarian.prices6();
							System.out.println("");
						}
						
						//end of 1 1st phase
						
						
						else if(total2==12||total2==21) {
							nonVegetarian.prices12();
							System.out.println("");
						}
						
						else if(total2==13||total2==31) {
							nonVegetarian.prices13();
							System.out.println("");
						}
						else if(total2==23||total2==32) {
							nonVegetarian.prices23();
							System.out.println("");
						}
						
						
						// end of two 1st phase
						
						else if(total2==123||total2==132||total2==213||
								total2==231||total2==321||total2==312) {
							nonVegetarian.prices123();
							System.out.println("");
						}
						
						
						//end of all 1st phase
						
						
						
						//starting of 2nd second phase
						
						else if(total2==45||total2==54) {
							nonVegetarian.prices45();
							System.out.println("");
						}
						
						else if(total2==46||total2==64) {
							nonVegetarian.prices46();
							System.out.println("");
						}
						else if(total2==56||total2==65) {
							nonVegetarian.prices56();
							System.out.println("");
						}
						else if(total2==456||total2==465||total2==546||
								total2==564||total2==654||total2==645) {
							nonVegetarian.prices456();
							System.out.println("");
						}
						
						
						else {
							System.out.println("");
						}
						break;
						}
					}
					default:
					}
					
				}
				
				break;
			}
			default:
				
			}
	    	
	    	
	    	
	    	
	    }
	    }

	}

}
